﻿
Configuration FormatDisk {
    param
    #v1.4
    (
        [Parameter(Mandatory)]
        [string]$DriveLetter,

        [Parameter(Mandatory)]
        [int]$DiskId
        
    )

    Import-DscResource -ModuleName xStorage
    
    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }
                
        xWaitforDisk Disk2
        {
            DiskId =  $DiskId
            RetryIntervalSec = 60
            RetryCount = 60
        }
        
        xDisk GVolume
        {
            DiskId = $DiskId
            DriveLetter = ("$DriveLetter")
            FSLabel = 'Data'
            FSFormat = 'NTFS'
            DependsOn = '[xWaitForDisk]Disk2'
        }
   }
}