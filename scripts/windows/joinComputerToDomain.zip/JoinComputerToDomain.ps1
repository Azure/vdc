﻿Configuration JoinComputerToDomain {
    param
    #v1.4
    (
        [Parameter(Mandatory)]
        [string]$DomainName,
      
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds,
        
        [Parameter(Mandatory)]
        $ServerName
    )
    
    Import-DscResource -ModuleName ComputerManagementDSC
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)

    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }
        Computer JoinDomain
        {
            Name       = $ServerName
            DomainName = $DomainName
            Credential = $DomainCreds # Credential to join to domain
        }
    }
} 