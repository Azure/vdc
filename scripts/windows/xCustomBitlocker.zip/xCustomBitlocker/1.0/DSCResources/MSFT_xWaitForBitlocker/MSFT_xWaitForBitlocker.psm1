﻿function Get-VolumeStatus {
    [OutputType([Boolean])]
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [String]
        $MountPoint
    )

    Write-Verbose $"Checking bitlocker status of drive: ($MountPoint)"

    while($true)
    {
        $drive_status = Get-BitLockerVolume -MountPoint $MountPoint | Select-Object -Property "VolumeStatus";

        if($drive_status.VolumeStatus -eq "FullyEncrypted")
        {
            break;
        }
        else
        {
            Start-Sleep -Seconds 2
            Write-Verbose "Not encrypted yet, sleeping until the next check"
        }
    }

    return $true;
}

function Get-TargetResource
{
    param
    (
        [Parameter(Mandatory)]
        [int]$DiskNumber
    )

        $getTargetResourceResult = $null;

        <# Insert logic that uses the mandatory parameter values to get the website and assign it to a variable called $Website #>
        <# Set $ensureResult to "Present" if the requested website exists and to "Absent" otherwise #>

        # Add all Website properties to the hash table
        # This simple example assumes that $Website is not null
        $getTargetResourceResult = @{
                                      DiskNumber = $DiskNumber
                                    }

        $getTargetResourceResult;
}

# The Set-TargetResource function is used to create, delete or configure a website on the target machine.
function Set-TargetResource
{
    param
    (
        [Parameter(Mandatory)]
        [int]$DiskNumber
    )

    $result = $false

    try
    {
        $all_disks_info = Get-BitLockerVolume | Where-Object -Property KeyProtector -NE "";

        if($DiskNumber -eq -1)
        {
            Write-Verbose "Analyzing statuses of all drives"

            for($i = 0; $i -lt $all_disks_info.length; $i++)
            {
                $result = Get-VolumeStatus -MountPoint $all_disks_info[$i].MountPoint;
                Write-Verbose -Message $"Disk: $($all_disks_info[$i].MountPoint) is now fully encrypted"
            }
        }
        else
        {
            $drive_letter = $all_disks_info[$DiskNumber].MountPoint

            Write-Verbose $"Analyzing the status of Drive: ($drive_letter)"
            try
            {
                $result = Get-VolumeStatus -MountPoint $all_disks_info[$DiskNumber].MountPoint;
                Write-Verbose -Message $"Disk: $($all_disks_info[$i].MountPoint) is now fully encrypted"
            }
            catch
            {
                if ($error[0]) {Write-Verbose $error[0].Exception}
                Write-Verbose -Message "Disk Number does not exist";
            }
        }
    }
    catch
    {
        if ($error[0]) {Write-Verbose $error[0].Exception}
        Write-Verbose -Message "Disk verification failed";
    }
}

function Test-TargetResource
{
    [OutputType([System.Boolean])]
    param
    (
        [parameter(Mandatory = $true)]
        [int]
        $DiskNumber
    )

    Write-Verbose -Message $"Checking DiskId: $("$DiskNumber")";
	
	$all_disks_info = Get-BitLockerVolume | Where-Object -Property KeyProtector -NE "";
	$fully_encrypted_count = 1;
	
	if($DiskNumber -eq -1)
	{
        Write-Verbose -Message "Checking all drives for bitlocker encryption status";

		for($i = 0; $i -lt $all_disks_info.length; $i++)
		{
			$drive_status = Get-BitLockerVolume -MountPoint $all_disks_info[$i].MountPoint | Select-Object -Property "VolumeStatus";
			
			if($drive_status -eq 'FullyEncrypted')
			{
				$fully_encrypted_count = $fully_encrypted_count + 1
			}
		}
		
		if($fully_encrypted_count -eq $all_disks_info)
		{
            Write-Verbose -Message "Drives are fully encrypted";
			return $true;
		}
		
        Write-Verbose -Message "Drives are not fully encrypted yet";
		return $false;
	}
	else
	{
		$drive_status = Get-BitLockerVolume -MountPoint $all_disks_info[$DiskNumber].MountPoint | Select-Object -Property "VolumeStatus";

        if($drive_status -eq "FullyEncrypted")
        {
            Write-Verbose -Message "Drive fully encrypted";
            return $true
        }

        Write-Verbose -Message "Drive not fully encrypted yet";
		return $false;
         
	}
}

Export-ModuleMember -Function *-TargetResource
